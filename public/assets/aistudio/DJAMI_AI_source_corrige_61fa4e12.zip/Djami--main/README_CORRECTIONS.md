# DJAMI source — corrected working copy

Read **CORRECTIONS_DJAMI_FR.md** for the French change log, build commands, tested items, and platform limits.

This is a source archive, not a compiled or device-tested APK. Build and run the existing test suite before distributing it.
