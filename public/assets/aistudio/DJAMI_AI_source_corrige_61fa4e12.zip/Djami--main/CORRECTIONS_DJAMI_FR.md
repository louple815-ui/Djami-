# DJAMI AI — corrections du système vocal

## Objet

Cette archive contient une version corrigée du **code source** de DJAMI AI. Elle conserve l'interface et les fonctions existantes et corrige la coordination des moteurs vocaux Android.

## Modifications apportées

- **Reconnaissance vocale (`SpeechRecognizerManager.kt`)** : privilégie le moteur local Android lorsqu'il est disponible, demande le français `fr-FR`, ignore les doubles démarrages, sérialise les opérations sur le thread principal, détruit les sessions annulées et utilise le moteur système si le moteur local ne prend pas en charge la langue ou échoue sur certains codes d'erreur.
- **Synthèse vocale (`TtsManager.kt`)** : centralise la lecture, conserve uniquement la dernière demande en attente pendant l'initialisation, utilise `QUEUE_FLUSH`, sécurise les callbacks de fin et permet de reprendre l'état suivant après la fin ou l'échec de la lecture.
- **Veille (`WakeWordService.kt`)** : ajoute des actions explicites de démarrage en pause, pause, reprise et arrêt ; empêche plusieurs redémarrages différés ; utilise une reprise plus lente pour les erreurs réseau ; évite les déclenchements sur toute phrase qui mentionne simplement « DJAMI » ; transmet la détection à l'activité et à la notification, afin que la notification reste une solution de secours si Android bloque le lancement de l'activité en arrière-plan.
- **Coordination (`DjamiViewModel.kt`)** : met en pause la veille pendant l'écoute manuelle et la lecture de DJAMI, puis la reprend quand l'interaction est terminée. Le réglage de veille est mémorisé. L'activation prépare le service en pause pour éviter que le microphone entende la confirmation vocale.
- **Permissions (`DjamiScreen.kt`)** : après la demande de permission, reprend l'action voulue (parler ou activer la veille) au lieu de toujours démarrer l'écoute manuelle. La veille peut toujours être arrêtée même si la permission microphone a été refusée.
- **Réveil (`MainActivity.kt`)** : consomme les données du mot d'activation pour éviter de répéter l'action à cause d'un ancien Intent et parle avant de commencer l'écoute manuelle.

## Vérifications réalisées dans cet environnement

- Le ZIP source d'origine a été extrait et les fichiers Kotlin concernés ont été inspectés et modifiés.
- La structure XML du manifeste et l'intégrité de la nouvelle archive doivent être vérifiées à la création du paquet.
- Le parsing Kotlin ne signale pas d'erreur de syntaxe, mais le contrôle par `kotlinc` sans Android SDK ni dépendances Android ne constitue pas une compilation Android.

## Vérifications non réalisées

La compilation Gradle et les tests Android **n'ont pas pu être exécutés ici** : le wrapper a tenté de télécharger Gradle 9.3.1 depuis `services.gradle.org`, mais l'environnement n'a pas d'accès DNS/réseau (`UnknownHostException`). L'APK corrigé n'est donc pas inclus, car je ne peux pas affirmer qu'il a été compilé ni installé avec succès.

## Compilation à exécuter avec Android Studio ou un environnement connecté

Depuis la racine du projet :

```bash
./gradlew testDebugUnitTest
./gradlew assembleDebug
```

L'APK de débogage sera normalement généré dans `app/build/outputs/apk/debug/`.

## Limites Android à connaître

- Le comportement dépend de la version Android, du service de reconnaissance vocale installé et des données françaises présentes sur le téléphone.
- `EXTRA_PREFER_OFFLINE` est une préférence, pas une garantie de reconnaissance sans réseau. Le code essaie le moteur local Android quand le système le déclare disponible, mais doit parfois se rabattre sur le service installé.
- Une veille vocale permanente basée sur `SpeechRecognizer` n'a pas l'efficacité ni la robustesse d'un mot d'activation matériel tel que celui d'un assistant système. Pour s'approcher davantage de Siri en faible consommation et hors ligne, il faut intégrer et tester un véritable moteur de détection de mot-clé local ainsi que son modèle acoustique. Ce modèle n'était pas fourni dans le ZIP d'origine.
- Android peut empêcher le lancement automatique d'une activité depuis l'arrière-plan. Dans ce cas, la notification de DJAMI permet à l'utilisateur d'ouvrir l'application.
- Aucun logiciel ne peut être garanti « sans aucune erreur » sans compilation, tests unitaires, tests d'intégration et essais sur les appareils cibles.

## Archive

L'ancien APK intégré dans l'archive fournie a été omis de cette archive corrigée afin de ne pas le confondre avec un APK construit à partir des nouveaux fichiers source.

## Références Android officielles

- `RecognizerIntent.EXTRA_PREFER_OFFLINE` reste une préférence qui peut être ignorée par un moteur vocal : https://developer.android.com/reference/android/speech/RecognizerIntent
- Types et prérequis du service de premier plan microphone : https://developer.android.com/develop/background-work/services/fgs/service-types
- Restrictions Android sur les services microphone démarrés en arrière-plan : https://developer.android.com/develop/background-work/services/fgs/restrictions-bg-start
