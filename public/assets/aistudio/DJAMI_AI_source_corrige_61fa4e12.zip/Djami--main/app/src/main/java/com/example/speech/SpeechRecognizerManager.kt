package com.example.speech

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed class RecognitionState {
    data object Idle : RecognitionState()
    data object Ready : RecognitionState()
    data object Listening : RecognitionState()
    data object Processing : RecognitionState()
    data class Success(val recognizedText: String) : RecognitionState()
    data class Error(val message: String, val errorCode: Int) : RecognitionState()
}

/**
 * Single owner for the foreground/manual speech-recognition session.
 * All SpeechRecognizer operations are serialized on the main thread, as required by Android.
 */
class SpeechRecognizerManager(
    private val context: Context,
    private val onFinalResult: (String) -> Unit,
    private val onPartialResult: (String) -> Unit = {}
) {
    private val tag = "DJAMI_SPEECH"
    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())

    private var speechRecognizer: SpeechRecognizer? = null
    private var isCurrentlyListening = false
    private var isDestroyed = false
    private var usingOnDeviceRecognizer = false
    private var hasRetriedWithRemoteRecognizer = false

    private val _state = MutableStateFlow<RecognitionState>(RecognitionState.Idle)
    val state: StateFlow<RecognitionState> = _state.asStateFlow()

    private val _partialText = MutableStateFlow("")
    val partialText: StateFlow<String> = _partialText.asStateFlow()

    val isRecognitionAvailable: Boolean
        get() = SpeechRecognizer.isRecognitionAvailable(appContext)

    /** Prefer a genuinely on-device recognizer when Android exposes one; otherwise use the
     * installed system recognizer and ask it to prefer offline processing where supported. */
    fun startListening() {
        mainHandler.post {
            if (isDestroyed) return@post
            if (isCurrentlyListening) {
                Log.d(tag, "Une session de reconnaissance est déjà active; démarrage ignoré.")
                return@post
            }
            if (!SpeechRecognizer.isRecognitionAvailable(appContext)) {
                _state.value = RecognitionState.Error(
                    "Aucun service de reconnaissance vocale n'est installé ou disponible.",
                    -1
                )
                return@post
            }

            _partialText.value = ""
            hasRetriedWithRemoteRecognizer = false
            startRecognizer(preferOnDevice = supportsOnDeviceRecognition())
        }
    }

    private fun supportsOnDeviceRecognition(): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            try {
                SpeechRecognizer.isOnDeviceRecognitionAvailable(appContext)
            } catch (e: Exception) {
                Log.w(tag, "Vérification du moteur local impossible: ${e.message}")
                false
            }

    private fun startRecognizer(preferOnDevice: Boolean) {
        if (isDestroyed) return
        destroyRecognizerOnMainThread()

        try {
            val recognizer = if (preferOnDevice && supportsOnDeviceRecognition()) {
                usingOnDeviceRecognizer = true
                SpeechRecognizer.createOnDeviceSpeechRecognizer(appContext)
            } else {
                usingOnDeviceRecognizer = false
                SpeechRecognizer.createSpeechRecognizer(appContext)
            }
            speechRecognizer = recognizer
            recognizer.setRecognitionListener(createListener(recognizer))

            val languageTag = "fr-FR"
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languageTag)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, appContext.packageName)
                // A preference only; Android may still use a network service if local recognition
                // is not available. A true offline guarantee requires an on-device recognizer.
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }

            isCurrentlyListening = true
            _state.value = RecognitionState.Listening
            recognizer.startListening(intent)
            Log.d(tag, "Reconnaissance démarrée (sur appareil=$usingOnDeviceRecognizer).")
        } catch (e: Exception) {
            isCurrentlyListening = false
            Log.e(tag, "Démarrage de la reconnaissance impossible", e)
            destroyRecognizerOnMainThread()
            _state.value = RecognitionState.Error(
                "Impossible de démarrer la reconnaissance vocale. Vérifiez les permissions du microphone et le moteur vocal Android.",
                -1
            )
        }
    }

    private fun createListener(owner: SpeechRecognizer): RecognitionListener =
        object : RecognitionListener {
            private fun isCurrentSession(): Boolean = !isDestroyed && speechRecognizer === owner

            override fun onReadyForSpeech(params: Bundle?) {
                if (isCurrentSession()) _state.value = RecognitionState.Ready
            }

            override fun onBeginningOfSpeech() {
                if (isCurrentSession()) _state.value = RecognitionState.Listening
            }

            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit

            override fun onEndOfSpeech() {
                if (!isCurrentSession()) return
                isCurrentlyListening = false
                _state.value = RecognitionState.Processing
            }

            override fun onError(error: Int) {
                if (!isCurrentSession()) return
                isCurrentlyListening = false
                Log.w(tag, "Erreur de reconnaissance ($error): ${mapErrorCodeToMessage(error)}")

                // Some devices expose an on-device service that cannot handle French. Retry once
                // with the system recognizer rather than leaving the user with a dead microphone.
                val canFallback = usingOnDeviceRecognizer && !hasRetriedWithRemoteRecognizer &&
                    (error == LANGUAGE_NOT_SUPPORTED || error == LANGUAGE_UNAVAILABLE ||
                        error == SpeechRecognizer.ERROR_SERVER || error == SpeechRecognizer.ERROR_NETWORK ||
                        error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT)
                if (canFallback) {
                    hasRetriedWithRemoteRecognizer = true
                    Log.i(tag, "Le moteur local ne peut pas traiter cette demande; essai du moteur système.")
                    startRecognizer(preferOnDevice = false)
                    return
                }

                _state.value = RecognitionState.Error(mapErrorCodeToMessage(error), error)
                destroyRecognizerOnMainThread()
            }

            override fun onResults(results: Bundle?) {
                if (!isCurrentSession()) return
                isCurrentlyListening = false
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull()?.trim()
                if (!text.isNullOrBlank()) {
                    _partialText.value = text
                    _state.value = RecognitionState.Success(text)
                    onFinalResult(text)
                } else {
                    _state.value = RecognitionState.Error(
                        "Aucune parole n'a été reconnue. Parlez clairement puis réessayez.",
                        SpeechRecognizer.ERROR_NO_MATCH
                    )
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                if (!isCurrentSession()) return
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull()?.trim()
                if (!text.isNullOrBlank()) {
                    _partialText.value = text
                    onPartialResult(text)
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) = Unit
        }

    fun stopListening() {
        mainHandler.post {
            if (isDestroyed) return@post
            val recognizer = speechRecognizer
            if (recognizer == null || !isCurrentlyListening) return@post
            try {
                _state.value = RecognitionState.Processing
                recognizer.stopListening()
            } catch (e: Exception) {
                Log.w(tag, "Arrêt de la reconnaissance impossible: ${e.message}")
                isCurrentlyListening = false
                _state.value = RecognitionState.Error("Impossible d'arrêter proprement l'écoute.", -1)
            }
        }
    }

    fun cancel() {
        mainHandler.post {
            if (isDestroyed) return@post
            isCurrentlyListening = false
            destroyRecognizerOnMainThread()
            _state.value = RecognitionState.Idle
        }
    }

    private fun destroyRecognizerOnMainThread() {
        val oldRecognizer = speechRecognizer
        speechRecognizer = null
        isCurrentlyListening = false
        try {
            oldRecognizer?.cancel()
        } catch (e: Exception) {
            Log.d(tag, "Annulation du recognizer ignorée: ${e.message}")
        }
        try {
            oldRecognizer?.destroy()
        } catch (e: Exception) {
            Log.w(tag, "Destruction du recognizer impossible: ${e.message}")
        }
    }

    private fun mapErrorCodeToMessage(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_AUDIO -> "Erreur de capture audio. Vérifiez le microphone et fermez les applications qui l'utilisent."
        SpeechRecognizer.ERROR_CLIENT -> "La reconnaissance vocale a été interrompue. Appuyez sur le micro pour réessayer."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Permission du microphone manquante. Autorisez DJAMI dans les paramètres Android."
        SpeechRecognizer.ERROR_NETWORK -> "Le service vocal a rencontré une erreur réseau. Vérifiez Internet ou la disponibilité du moteur vocal local."
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Le service vocal n'a pas répondu à temps. Réessayez ou utilisez la saisie écrite."
        SpeechRecognizer.ERROR_NO_MATCH -> "Aucune parole n'a été reconnue. Parlez plus près du microphone."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Le moteur vocal est occupé. Attendez un instant puis réessayez."
        SpeechRecognizer.ERROR_SERVER -> "Le service de reconnaissance vocale a échoué. Réessayez ou vérifiez les services vocaux Android."
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Aucune parole détectée. Parlez après l'activation du microphone."
        LANGUAGE_NOT_SUPPORTED -> "Le moteur vocal ne prend pas en charge le français demandé. Vérifiez les langues installées sur Android."
        LANGUAGE_UNAVAILABLE -> "Les données françaises du moteur vocal ne sont pas disponibles. Installez la langue française dans les services vocaux Android."
        else -> "Erreur de reconnaissance vocale (code $error). Vous pouvez réessayer ou écrire votre message."
    }

    fun destroy() {
        mainHandler.post {
            if (isDestroyed) return@post
            isDestroyed = true
            mainHandler.removeCallbacksAndMessages(null)
            destroyRecognizerOnMainThread()
        }
    }

    companion object {
        // API 31+ constants, represented by their documented numeric values so the app remains
        // compatible with the configured minSdk while safely handling older devices.
        private const val LANGUAGE_NOT_SUPPORTED = 12
        private const val LANGUAGE_UNAVAILABLE = 13
    }
}
