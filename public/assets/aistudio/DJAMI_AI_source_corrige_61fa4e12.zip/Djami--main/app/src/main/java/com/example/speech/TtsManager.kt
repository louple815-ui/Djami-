package com.example.speech

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/** One application-wide TTS manager. Speech is flush-based so utterances never overlap. */
class TtsManager(private val context: Context) : TextToSpeech.OnInitListener {
    private val tag = "DJAMI_TTS"
    private val mainHandler = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var isDestroyed = false
    private var currentUtteranceId: String? = null

    private data class PendingUtterance(val text: String, val onComplete: (() -> Unit)?)
    private val pendingSpeechQueue = mutableListOf<PendingUtterance>()
    private val completionCallbacks = ConcurrentHashMap<String, () -> Unit>()

    private val _isInitialized = MutableStateFlow(false)
    val isInitialized: StateFlow<Boolean> = _isInitialized.asStateFlow()
    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()
    private val _hasFemaleVoice = MutableStateFlow(false)
    val hasFemaleVoice: StateFlow<Boolean> = _hasFemaleVoice.asStateFlow()
    private val _frenchVoiceAvailable = MutableStateFlow(true)
    val frenchVoiceAvailable: StateFlow<Boolean> = _frenchVoiceAvailable.asStateFlow()

    var speechRate: Float = 1.0f
        set(value) {
            val safeValue = value.coerceIn(0.5f, 2.0f)
            field = safeValue
            mainHandler.post { tts?.setSpeechRate(safeValue) }
        }
    var speechPitch: Float = 1.08f
        set(value) {
            val safeValue = value.coerceIn(0.5f, 2.0f)
            field = safeValue
            mainHandler.post { tts?.setPitch(safeValue) }
        }

    init {
        mainHandler.post { if (!isDestroyed) tts = TextToSpeech(context.applicationContext, this) }
    }

    override fun onInit(status: Int) {
        if (isDestroyed) return
        if (status != TextToSpeech.SUCCESS) {
            Log.e(tag, "Échec de l'initialisation de TextToSpeech: status=$status")
            _isInitialized.value = false
            return
        }

        val engine = tts ?: return
        try {
            val languageResult = engine.setLanguage(Locale.FRANCE)
            val frenchAvailable = languageResult != TextToSpeech.LANG_MISSING_DATA &&
                languageResult != TextToSpeech.LANG_NOT_SUPPORTED
            _frenchVoiceAvailable.value = frenchAvailable
            if (!frenchAvailable) {
                Log.w(tag, "Données vocales françaises absentes; utilisation de la langue par défaut.")
                engine.setLanguage(Locale.getDefault())
            }
            configureFrenchVoiceIfAvailable(engine)
            engine.setSpeechRate(speechRate)
            engine.setPitch(speechPitch)
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    mainHandler.post {
                        if (!isDestroyed && utteranceId != null && utteranceId == currentUtteranceId) {
                            _isSpeaking.value = true
                        }
                    }
                }

                override fun onDone(utteranceId: String?) {
                    finishUtterance(utteranceId)
                }

                override fun onError(utteranceId: String?) {
                    Log.e(tag, "Erreur de lecture TTS: $utteranceId")
                    finishUtterance(utteranceId)
                }

                override fun onStop(utteranceId: String?, interrupted: Boolean) {
                    mainHandler.post {
                        if (utteranceId != null && utteranceId == currentUtteranceId) {
                            currentUtteranceId = null
                            _isSpeaking.value = false
                        }
                    }
                    if (interrupted && utteranceId != null) completionCallbacks.remove(utteranceId)
                }
            })
            _isInitialized.value = true

            val pending = synchronized(pendingSpeechQueue) {
                pendingSpeechQueue.toList().also { pendingSpeechQueue.clear() }
            }
            // QUEUE_FLUSH semantics: only the most recent request should survive initialization.
            pending.lastOrNull()?.let { speak(it.text, it.onComplete) }
        } catch (e: Exception) {
            Log.e(tag, "Configuration du moteur vocal impossible", e)
            _isInitialized.value = false
        }
    }

    private fun configureFrenchVoiceIfAvailable(engine: TextToSpeech) {
        try {
            val installedVoices: Set<Voice> = engine.voices ?: emptySet()
            val frenchVoices: List<Voice> = installedVoices
                .filter { it.locale.language.equals("fr", ignoreCase = true) }
            val candidate = frenchVoices.firstOrNull { voice ->
                val name = voice.name.lowercase(Locale.ROOT)
                name.contains("female") || name.contains("femme") ||
                    name.contains("fr-fr-x-vfb") || name.contains("fr-fr-x-vfc")
            } ?: frenchVoices.firstOrNull()

            if (candidate != null) {
                engine.voice = candidate
                val name = candidate.name.lowercase(Locale.ROOT)
                _hasFemaleVoice.value = name.contains("female") || name.contains("femme")
                Log.i(tag, "Voix française sélectionnée: ${candidate.name}")
            } else {
                _hasFemaleVoice.value = false
                Log.w(tag, "Aucune voix française installée dans le moteur TTS.")
            }
        } catch (e: Exception) {
            _hasFemaleVoice.value = false
            Log.w(tag, "Sélection de voix française impossible: ${e.message}")
        }
    }

    /** Called on completion or failure so callers can safely resume their next state. */
    private fun finishUtterance(utteranceId: String?) {
        mainHandler.post {
            if (isDestroyed) return@post
            if (utteranceId != null && utteranceId == currentUtteranceId) {
                currentUtteranceId = null
                _isSpeaking.value = false
            }
            val callback = if (utteranceId != null) completionCallbacks.remove(utteranceId) else null
            try {
                callback?.invoke()
            } catch (e: Exception) {
                Log.e(tag, "Callback de fin de lecture en erreur", e)
            }
        }
    }

    fun speak(text: String, onComplete: (() -> Unit)? = null) {
        if (text.isBlank() || isDestroyed) {
            onComplete?.invoke()
            return
        }
        mainHandler.post {
            if (isDestroyed) {
                onComplete?.invoke()
                return@post
            }
            if (!_isInitialized.value || tts == null) {
                synchronized(pendingSpeechQueue) {
                    // One active voice response at a time; preserve the latest request only.
                    pendingSpeechQueue.clear()
                    pendingSpeechQueue.add(PendingUtterance(text, onComplete))
                }
                return@post
            }

            stopInternal(clearPending = true)
            val utteranceId = "DJAMI_TTS_${System.nanoTime()}"
            currentUtteranceId = utteranceId
            if (onComplete != null) completionCallbacks[utteranceId] = onComplete
            val params = Bundle().apply {
                putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
            }
            val result = tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
            if (result == TextToSpeech.ERROR) {
                completionCallbacks.remove(utteranceId)
                currentUtteranceId = null
                _isSpeaking.value = false
                Log.e(tag, "Le moteur TTS a refusé la phrase.")
                onComplete?.invoke()
            }
        }
    }

    fun stop() {
        mainHandler.post { stopInternal(clearPending = true) }
    }

    private fun stopInternal(clearPending: Boolean) {
        currentUtteranceId = null
        try {
            tts?.stop()
        } catch (e: Exception) {
            Log.w(tag, "Arrêt du TTS impossible: ${e.message}")
        }
        _isSpeaking.value = false
        completionCallbacks.clear()
        if (clearPending) synchronized(pendingSpeechQueue) { pendingSpeechQueue.clear() }
    }

    fun openTtsSettings() {
        try {
            val intent = Intent("com.android.settings.TTS_SETTINGS").apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e(tag, "Impossible d'ouvrir les paramètres TTS", e)
        }
    }

    fun destroy() {
        mainHandler.post {
            if (isDestroyed) return@post
            isDestroyed = true
            completionCallbacks.clear()
            synchronized(pendingSpeechQueue) { pendingSpeechQueue.clear() }
            try {
                tts?.stop()
                tts?.shutdown()
            } catch (e: Exception) {
                Log.w(tag, "Destruction du TTS impossible: ${e.message}")
            } finally {
                tts = null
                currentUtteranceId = null
                _isInitialized.value = false
                _isSpeaking.value = false
            }
        }
    }
}
